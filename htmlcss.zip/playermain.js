
var myAudio = document.getElementById("zxc"); 

function play() { 
  if (myAudio.paused) 
    myAudio.play(); 
  else 
    myAudio.pause(); 
} 
